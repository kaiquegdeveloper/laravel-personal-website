<?php $__env->startSection('content'); ?>
    <canvas height="700px"></canvas>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\site-ak\resources\views/nothing.blade.php ENDPATH**/ ?>