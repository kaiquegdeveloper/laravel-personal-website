@extends('templates.master')

@section('content')
    <canvas height="700px"></canvas>
@endsection