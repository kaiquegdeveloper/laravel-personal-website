<?php $__env->startSection('title', 'Balance'); ?>



<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="col-md-12">
    <h1>Postagens</h1>

    <ol class="breadcrumb">
      <li><a href="<?php echo e(route('admin.index')); ?>">Dashboard</a></li>&nbsp;
      <li><a href="<?php echo e(route('post.index')); ?>">Postagens</a></li>
    </ol>
  </div>
</div>

<div class="row">
  <div class="col">
    <?php echo $__env->make('includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="d-flex">
      <a href="<?php echo e(route('post.create')); ?>" class="btn btn-primary pull-left" style="margin-right:10px">Nova
        postagem</a>
    </div>
    <!-- /.box-header -->
    <br>
    <div class="box-body table-responsive no-padding">
      <table class="table table-hover">
        <tbody>
          <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Atualizado em</th>
            <th></th>
          </tr>
          <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($post->id); ?></td>
            <td><?php echo e($post->title); ?></td>
            <td><?php echo e(date('d-m-Y H:i', strtotime($post->updated_at))); ?></td>
            <td>
              <div class="btn-group"><a href="<?php echo e(route('post.index')); ?>/<?php echo e($post->id); ?>/edit"
                  class="btn btn-warning pull-left">Editar</a></div>
              <div class="btn-group">
                <form action="<?php echo e(route('post.destroy',$post->id)); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <?php echo e(method_field('DELETE')); ?>

                  <button class="btn btn-danger" onclick="return confirm('Deseja realmente excluir?')"
                    type="submit">Excluir</button>
                </form>
              </div>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <!-- /.box-body -->
  </div>
  <!-- /.box -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\devkaique\resources\views/admin/post/index.blade.php ENDPATH**/ ?>