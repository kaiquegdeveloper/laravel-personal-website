<?php $__env->startSection('title'); ?>
<?php echo e($post->meta_title); ?> | AK Desenvolvimento
<?php $__env->stopSection(); ?>
<?php $__env->startSection('seo'); ?>
<meta name="author" content="AK Desenvolvimento">
<meta name="description" content="<?php echo e($post->meta_description); ?>">
<meta name="keywords" content="<?php echo e($post->meta_keywords); ?>">
<meta name="title" content="<?php echo e($post->meta_title); ?>">

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website">
<meta property="og:url" content="http://akdesenvolvimento.com.br/blog/<?php echo e($post->url); ?>">
<meta property="og:title" content="<?php echo e($post->meta_title); ?>">
<meta property="og:description" content="<?php echo e($post->meta_description); ?>">
<meta property="og:image" content="http://akdesenvolvimento.com.br/images/uploads/blog/<?php echo e($post->main_image); ?>">

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="http://akdesenvolvimento.com.br/images/uploads/blog/<?php echo e($post->main_image); ?>">
<meta property="twitter:title" content="<?php echo e($post->meta_title); ?>">
<meta property="twitter:description" content="<?php echo e($post->meta_description); ?>">
<meta property="twitter:image" content="http://lp.akdesenvolvimento.com.br/hospedagem/img/logo/dark.png">

<meta name="robots" content="index, follow">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Page Content -->
<canvas height="50px"></canvas>
<div class="container">

    <div class="row">

        <!-- Post Content Column -->
        <div class="col-lg-8">

            <!-- Title -->
            <h1 class="mt-4"><?php echo e($post->title ?? ''); ?></h1>

            <!-- Author -->
            <p class="lead">
                por: <strong> Amon Gustavo </strong>
            </p>
            <hr>
        <img src="<?php echo e(asset('images/uploads/blog')); ?>/<?php echo e($post->main_image); ?>" class="img-fluid">
            <br>
            <br>
            <?php echo $post->content ?? 'aaaa'; ?>

            <hr>

            

            <!-- Single Comment -->
            

        </div>

        <!-- Sidebar Widgets Column -->
        <div class="col-md-4">

            <!-- Categories Widget -->
            <div class="card my-4">
                <h5 class="card-header">Categorias</h5>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md">
                            <ul class="list-unstyled mb-0">
                                <?php $__currentLoopData = $post->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                <button class="btn btn-secondary"><?php echo e($cat->title); ?></button>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Side Widget -->
            <div class="card my-4">
                <h5 class="card-header">Newsletter</h5>
                <div class="card-body">
                    Inscreva-se na nossa newsletter!
                    <form class="form-group" action="">
                        <div class="input-group input-group-sm mb-3">
                            <input type="text" class="form-control" placeholder="Seu melhor email!"
                                aria-label="Seu melhor email!" aria-describedby="button-addon2">
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="button" id="button-addon2"><i
                                        class="fas fa-paper-plane"></i></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="card my-4">
                <div class="card-body">
                    <p>Postado em <?php echo e(Carbon\Carbon::parse($post->created_at)->format('d/m/Y | H:m')); ?></p>
                </div>
            </div>

        </div>

    </div>
    <!-- /.row -->

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\site-ak\resources\views/blog/post.blade.php ENDPATH**/ ?>