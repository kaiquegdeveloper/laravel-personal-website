<?php $__env->startSection('title'); ?>
Blog | AK Desenvolvimento
<?php $__env->stopSection(); ?>
<?php $__env->startSection('seo'); ?>
<meta name="author" content="AK Desenvolvimento">
<meta name="description" content="Nossa área onde nossos profissionais compartilham as novidades do mundo da tecnologia">
<meta name="keywords" content="blog,tecnologia,inovação,startup,noticias,postagens">
<meta name="robots" content="index, follow">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Page Content -->
<canvas height="70px"></canvas>
<!-- Page Content -->
<div class="container">

    <div class="row">
        <div class="col-md-4">
            <h1 class="my-4">Ultimas postagens
            </h1>
            <h4 class="text-muted">Aqui você confere as últimas novidades do mundo de TI</h4>
        </div>
        <div class="col-md-4">
            <div class="card my-4">
                <h5 class="card-header">Newsletter</h5>
                <div class="card-body">
                    Inscreva-se na nossa newsletter!
                    <form class="form-group" action="">
                        <div class="input-group input-group-sm mb-3">
                            <input type="text" class="form-control" placeholder="Seu melhor email!"
                                aria-label="Seu melhor email!" aria-describedby="button-addon2">
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="button" id="button-addon2"><i
                                        class="fas fa-paper-plane"></i></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

        </div>
        <div class="col-md-4">

            <!-- Categories Widget -->
            <div class="card my-4">
                <h5 class="card-header">Categorias</h5>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-">
                            <ul class="list-unstyled mb-0">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <button class="btn btn-sm btn-secondary"><?php echo e($cat->title); ?></button>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <div class="row">
        <!-- Blog Entries Column -->

        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6">

            <!-- Blog Post -->
            <div class="card mb-4">
                <img class="card-img-top" src="<?php echo e(asset('images/uploads/blog')); ?>/<?php echo e($post->main_image); ?>"
                    alt="Card image cap">
                <div class="card-body">
                    <h2 class="card-title"><?php echo e($post->title); ?></h2>
                    <p class="card-text"><?php echo e($post->description); ?></p>
                    <a href="<?php echo e(url('blog/')); ?>/<?php echo e($post->url); ?>" class="btn btn-primary">Continue lendo</a>
                </div>
                <div class="card-footer text-muted">
                    Postado em <?php echo e(Carbon\Carbon::parse($post->created_at)->format('d/m/Y | H:m')); ?> por:
                    <strong>Amon Gustavo</strong>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        
    </div>
    <br>
    <?php echo e($posts->links()); ?>

    <br><br><br>
    <!-- /.row -->

</div>

</div>
<?php echo $__env->make('templates.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\site-ak\resources\views/blog/index.blade.php ENDPATH**/ ?>