<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\site-ak\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>