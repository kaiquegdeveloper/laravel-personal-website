<?php $__env->startSection('title', 'Permissões'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="col-md-12">
    <h1>Paginas</h1>

    <ol class="breadcrumb">
      <li><a href="<?php echo e(route('admin.index')); ?>">Dashboard</a></li> &nbsp;
      <li><a href="">User</a></li>
    </ol>
  </div>
</div>
<div class="row">
  <div class="col">

    <?php echo $__env->make('includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="box">
      <div class="box-header">
        <h3 class="box-title"></h3>

        <div class="box-tools">
          <a href="<?php echo e(route('role.create')); ?>" class="btn btn-primary pull-left" style="margin-right:10px">Nova
            Função</a>

        </div>
      </div>
      <!-- /.box-header -->
      <div class="box-body table-responsive no-padding">
        <table class="table table-hover">
          <tbody>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th></th>
            </tr>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($role->id != 1): ?>
            <tr>
              <td><?php echo e($role->id); ?></td>
              <td><?php echo e($role->name); ?></td>
              <td>
                <div class="btn-group"><a href="<?php echo e(route('role.index')); ?>/<?php echo e($role->id); ?>/edit"
                    class="btn btn-warning pull-left">Editar</a></div>
                <?php //<a href="{{route('role.index')}}/{{$role->id}}/destroy" class="btn btn-danger">Deletar</a> ?>

                <div class="btn-group">
                  <form action="<?php echo e(route('role.destroy',$role->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('DELETE')); ?>

                    <button class="btn btn-danger" type="submit">Excluir</button>
                  </form>
                </div>
              </td>
            </tr>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\devkaique\resources\views/admin/role/index.blade.php ENDPATH**/ ?>