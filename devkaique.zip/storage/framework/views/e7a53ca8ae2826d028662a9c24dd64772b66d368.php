<?php $__env->startSection('title', 'Usuários'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="col-md-12">
    <h1>Usuários do Sistema</h1>

    <ol class="breadcrumb">
      <li><a href="<?php echo e(route('admin.index')); ?>">Dashboard</a></li> &nbsp;
      <li><a href="">Admin</a></li>

    </ol>
  </div>
</div>
<div class="row">
  <div class="col">
    <div class="box">
      <div class="box-header">
        <h3 class="box-title"></h3>

        <div class="box-tools">
          <a href="<?php echo e(route('user.create')); ?>" class="btn btn-primary pull-left" style="margin-right:10px">Novo
            Usuário</a>
        </div>
      </div>
      <!-- /.box-header -->
      <div class="box-body table-responsive no-padding">
        <table class="table table-hover">
          <tbody>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Atualizado em</th>
              <th></th>
            </tr>
            <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($admin->id == 1): ?>
            <tr>
              <td><?php echo e($admin->id); ?></td>
              <td><?php echo e($admin->user['name']); ?></td>
              <td><?php echo e($admin->updated_at); ?></td>
              <td>
              </td>
            </tr>
            <?php else: ?>
            <?php if(Auth::user()->id == $admin->user->id and Auth::user()->id != 1 ): ?>
            <tr>
              <td><?php echo e($admin->id); ?></td>
              <td><?php echo e($admin->user['name']); ?></td>
              <td><?php echo e($admin->updated_at); ?></td>
              <td>
              </td>
            </tr>
            <?php else: ?>
            <?php if($admin->user->roles[0]->id == 2 and Auth::user()->id != 1): ?>
            <tr>
              <td><?php echo e($admin->id); ?></td>
              <td><?php echo e($admin->user['name']); ?></td>
              <td><?php echo e($admin->updated_at); ?></td>
              <td>
              </td>
            </tr>
            <?php else: ?>
            <tr>
              <td><?php echo e($admin->id); ?></td>
              <td><?php echo e($admin->user['name']); ?></td>
              <td><?php echo e($admin->updated_at); ?></td>
              <td>

                <div class="btn-group"><a href="<?php echo e(route('user.show',$admin->id)); ?>" class="btn btn-default">Exibir</a>
                </div>
                <div class="btn-group"><a href="<?php echo e(route('user.index')); ?>/<?php echo e($admin->id); ?>/edit"
                    class="btn btn-warning">Editar</a></div>
                <div class="btn-group">
                  <form action="<?php echo e(route('user.destroy',$admin->id)); ?>" method="post">

                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('DELETE')); ?>

                    <button class="btn btn-danger" onclick="return confirm('Deseja realmente excluir?')"
                      type="submit">Excluir</button>
                  </form>
                </div>
              </td>
            </tr>
            <?php endif; ?>
            <?php endif; ?>

            <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\site-ak\resources\views/admin/user/index.blade.php ENDPATH**/ ?>