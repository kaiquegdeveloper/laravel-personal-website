<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\devkaique\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>