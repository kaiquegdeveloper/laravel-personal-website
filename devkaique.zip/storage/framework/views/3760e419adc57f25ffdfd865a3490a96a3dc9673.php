<?php $__env->startSection('title'); ?>
<?php echo e($post->meta_title); ?> | AK Desenvolvimento
<?php $__env->stopSection(); ?>
<?php $__env->startSection('seo'); ?>
<meta name="author" content="AK Desenvolvimento">
<meta name="description" content="<?php echo e($post->meta_description); ?>">
<meta name="keywords" content="<?php echo e($post->meta_keywords); ?>">
<meta name="title" content="<?php echo e($post->meta_title); ?>">

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website">
<meta property="og:url" content="http://akdesenvolvimento.com.br/blog/<?php echo e($post->url); ?>">
<meta property="og:title" content="<?php echo e($post->meta_title); ?>">
<meta property="og:description" content="<?php echo e($post->meta_description); ?>">
<meta property="og:image" content="http://akdesenvolvimento.com.br/images/uploads/blog/<?php echo e($post->main_image); ?>">

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="http://akdesenvolvimento.com.br/images/uploads/blog/<?php echo e($post->main_image); ?>">
<meta property="twitter:title" content="<?php echo e($post->meta_title); ?>">
<meta property="twitter:description" content="<?php echo e($post->meta_description); ?>">
<meta property="twitter:image" content="http://lp.akdesenvolvimento.com.br/hospedagem/img/logo/dark.png">

<meta name="robots" content="index, follow">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- ===== Start Blog ===== -->
    <section class="blog" id="blog">
      <div class="container">
          <h2 class="text-center"><?php echo e($post->title); ?></h2>
          <div class="row">
              <!-- Post-1 -->
              <div class="col-12">
                <div class="box">
                    <div class="image">
                        <img src="<?php echo e(asset('images/uploads/blog')); ?>/<?php echo e($post->main_image); ?>" alt="">
                    </div>
                    <div class="text">
                        
                        <p><?php echo $post->content; ?></p>
                        <h4>Postado em: <?php echo e(Carbon\Carbon::parse($post->created_at)->format('d/m/Y | H:m')); ?></h4>
                    </div>
                </div>
            </div>



          </div>
      </div>
  </section>
  <!-- ===== End Blog ===== -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\devkaique\resources\views/blog/post.blade.php ENDPATH**/ ?>