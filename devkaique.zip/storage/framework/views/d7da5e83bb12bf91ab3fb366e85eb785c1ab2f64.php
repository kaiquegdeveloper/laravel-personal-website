<?php $__env->startSection('title', 'Categorias de Post'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="col-md-12">
    <h1>Categorias de Post</h1>

    <ol class="breadcrumb">
      <li><a href="<?php echo e(route('admin.index')); ?>">Dashboard</a></li> &nbsp;
      <li><a href="">Categorias de Post</a></li>
    </ol>
  </div>
</div>
<div class="row">
  <div class="col">
    <?php echo $__env->make('includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="box">
      <div class="box-header">
        <h3 class="box-title"></h3>

        <div class="box-tools">
          <a href="<?php echo e(route('postCategory.create')); ?>" class="btn btn-primary pull-left" style="margin-right:10px">Nova
            Categoria</a>
        </div>
      </div>
      <br>
      <!-- /.box-header -->
      <div class="box-body table-responsive no-padding">
        <table class="table table-hover">
          <tbody>
            <tr>
              <th>ID</th>
              <th>Title</th>
              <th>Atualizado em</th>
              <th></th>
            </tr>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($category->id); ?></td>
              <td><?php echo e($category->title); ?></td>
              <td><?php echo e(date('d-m-Y H:i', strtotime($category->updated_at))); ?></td>
              <td>
                <div class="btn-group"><a href="<?php echo e(route('postCategory.index')); ?>/<?php echo e($category->id); ?>/edit"
                    class="btn btn-warning pull-left">Editar</a></div>
                <div class="btn-group">
                  <form action="<?php echo e(route('postCategory.destroy',$category->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('DELETE')); ?>

                    <button class="btn btn-danger" onclick="return confirm('Deseja realmente excluir?')"
                      type="submit">Excluir</button>
                  </form>
                </div>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\site-ak\resources\views/admin/postCategory/index.blade.php ENDPATH**/ ?>