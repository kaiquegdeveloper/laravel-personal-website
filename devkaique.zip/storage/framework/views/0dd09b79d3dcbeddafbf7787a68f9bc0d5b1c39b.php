<?php $__env->startSection('title', 'Clientes'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
  <div class="col-md-12">
    <h1>Edição de Usuário</h1>

    <ol class="breadcrumb">
      <li><a href="<?php echo e(route('admin.index')); ?>">Dashboard</a></li> &nbsp;
      <li><a href="">Cliente</a></li>
    </ol>
  </div>
</div>

<?php echo $__env->make('includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<form enctype="multipart/form-data" role="form" method="post"
  action=" <?php if(isset($user->id)): ?> <?php echo e(route('user.update',$user->id)); ?> <?php else: ?> <?php echo e(route('user.store')); ?> <?php endif; ?> ">
  <?php echo csrf_field(); ?>

  <div class="row">
    <div class="col-md-6">
      <div class="box box-danger">
        <div class="box-header with-border">
          <h3 class="box-title">Dados de Acesso</h3>
        </div>
        <?php if(isset($user->id)): ?>
        <input type="hidden" value="<?php echo e($user->id); ?>" name="id" />
        <?php echo e(method_field('PATCH')); ?>

        <?php endif; ?>
        <div class="box-body">
          <div class="form-group">
            <?php if(isset($user)): ?><?php echo e($user->name); ?><?php endif; ?>
          </div>
          <div class="form-group">
            <?php if(isset($user)): ?><?php echo e($user->email); ?><?php endif; ?>
          </div>
          <div class="form-group">


            <?php if(isset($user)): ?>
            <img src="/images/users/<?php echo e($user->image); ?>" width="200px" />
            <a id="show-input" href="#" onclick="show()" class="btn">Adicionar nova</a>
            <div id="input-image" style="display:none">
              <input name="image" type="file" />
            </div>
            <script>
              function show(){
                  document.getElementById('input-image').style.display = 'block';
              }
            </script>
            <?php else: ?>
            <input name="image" type="file" />
            <?php endif; ?>
          </div>
          <div class="form-group">

          </div>
        </div>
      </div>
    </div>
    <!-- coluna direita -->

    <div class="col-md-6">
      <div class="box box-success">
        <div class="box-header with-border">
          <h3 class="box-title">Documentos</h3>
        </div>
        <div class="box-body">
          <?php if(isset($user)): ?><?php echo e($user->numero_cadastro); ?><?php endif; ?>
          <div class="form-group">
            <label>RG</label>
            <?php if(isset($user)): ?><?php echo e($user->rg); ?><?php endif; ?>
          </div>
          <div class="form-group">
            <label>RG Expedição</label>
            <?php if(isset($user)): ?><?php echo e($user->rg_expedicao); ?><?php endif; ?>
          </div>
          <div class="form-group">
            <label>RG Orgão Expedidor</label>
            <?php if(isset($user)): ?><?php echo e($user->rg_orgaoexpedidor); ?><?php endif; ?>
          </div>
          <div class="form-group">
            <label>CPF</label>
            <?php if(isset($user)): ?><?php echo e($user->cpf); ?><?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="row">


    <div class="col-md-12">
      <div class="box box-info">
        <div class="box-header with-border">
          <h3 class="box-title">Naturalidade</h3>
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
          </div>
        </div>
        <div class="box-body">
          <div class="form-group col-md-2">
            <label>Data de Nascimento</label>
            <?php if(isset($user)): ?><?php echo e($user->data_nascimento); ?><?php endif; ?>
          </div>
          <div class="form-group col-md-6">
            <label>Local de Nascimento</label>
            <?php if(isset($user)): ?><?php echo e($user->local_nascimento); ?><?php endif; ?>
          </div>
          <div class="form-group col-md-2">
            <label>Tipo Sanguíneo</label>
            <?php if(isset($user)): ?><?php echo e($user->tipo_sanguineo); ?><?php endif; ?>
          </div>
          <div class="form-group col-md-8">
            <label>Nome do Pai</label>
            <?php if(isset($user)): ?><?php echo e($user->filiacao_pai); ?><?php endif; ?>
          </div>
          <div class="form-group col-md-4">
            <label>Data de Nascimento</label>
            <?php if(isset($user)): ?><?php echo e($user->filiacao_pai_nascimento); ?><?php endif; ?>
          </div>
          <div class="form-group col-md-8">
            <label>Nome da Mãe</label>
            <?php if(isset($user)): ?><?php echo e($user->filiacao_mae); ?><?php endif; ?>
          </div>
          <div class="form-group col-md-4">
            <label>Data de Nascimento</label>
            <?php if(isset($user)): ?><?php echo e($user->filiacao_mae_nascimento); ?><?php endif; ?>
          </div>
          <div class="form-group col-md-2">
            <label>Estado Civil</label>
            <?php if(isset($user)): ?><?php echo e($user->estado_civil); ?><?php endif; ?>
          </div>
          <div class="form-group col-md-2">
            <label>Data de Casamento</label>
            <?php if(isset($user)): ?><?php echo e($user->data_casamento); ?><?php endif; ?>
          </div>
          <div class="form-group col-md-6">
            <label>Nome da Esposa</label>
            <?php if(isset($user)): ?><?php echo e($user->nome_esposa); ?><?php endif; ?>
          </div>
          <div class="form-group col-md-2">
            <label>Data de Nascimento</label>
            <?php if(isset($user)): ?><?php echo e($user->data_nascimento_esposa); ?><?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="box box-info">
        <div class="box-header with-border">
          <h3 class="box-title">Contatos</h3>
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
          </div>
        </div>
        <div class="box-body">
          <div class="form-group col-md-5">
            <label>Endereço Residencial</label>
            <?php if(isset($user)): ?><?php echo e($user->endereco_residencial); ?><?php endif; ?>
          </div>
          <div class="form-group col-md-2">
            <label>CEP</label>
            <?php if(isset($user)): ?><?php echo e($user->endereco_cep); ?><?php endif; ?>
          </div>
          <div class="form-group col-md-2">
            <label>Bairro</label>
            <?php if(isset($user)): ?><?php echo e($user->endereco_bairro); ?><?php endif; ?>
          </div>
          <div class="form-group col-md-3">
            <label>Cidade</label>
            <?php if(isset($user)): ?><?php echo e($user->endereco_cidade); ?><?php endif; ?>
          </div>
          <div class="form-group col-md-2">
            <label>Telefone Residencial</label>
            <?php if(isset($user)): ?><?php echo e($user->telefone_residencial); ?><?php endif; ?>
          </div>
          <div class="form-group col-md-2">
            <label>Celular</label>
            <?php if(isset($user)): ?><?php echo e($user->celular); ?><?php endif; ?>
          </div>
          <div class="form-group col-md-2">
            <label>Telefone Comercial</label>
            <?php if(isset($user)): ?><?php echo e($user->telefone_comercial); ?><?php endif; ?>
          </div>
          <div class="form-group col-md-2">
            <label>Fax</label>
            <?php if(isset($user)): ?><?php echo e($user->fax); ?><?php endif; ?>
          </div>
          <div class="form-group col-md-2">
            <label>Telefone (outros)</label>
            <?php if(isset($user)): ?><?php echo e($user->telefone_outro); ?><?php endif; ?>
          </div>
          <div class="form-group col-md-6">
            <label>Idiomas</label>
            <?php if(isset($user)): ?><?php echo e($user->idiomas); ?><?php endif; ?>
          </div>
          <div class="form-group col-md-2">
            <label>Email (outros)</label>
            <?php if(isset($user)): ?><?php echo e($user->email_outro); ?><?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="box box-info">
        <div class="box-header with-border">
          <h3 class="box-title">Profissional</h3>
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
          </div>
        </div>
        <div class="box-body">
          <div class="form-group col-md-4">
            <label>Profissão</label>
            <?php if(isset($user)): ?><?php echo e($user->profissao); ?><?php endif; ?>
          </div>
          <div class="form-group col-md-4">
            <label>Ramo de Atividade</label>
            <?php if(isset($user)): ?><?php echo e($user->ramo_atividade); ?><?php endif; ?>
          </div>
          <div class="form-group col-md-4">
            <label>Endereço Comercial</label>
            <?php if(isset($user)): ?><?php echo e($user->endereco_profissional); ?><?php endif; ?>
          </div>
          <div class="form-group col-md-4">
            <label>CEP</label>
            <?php if(isset($user)): ?><?php echo e($user->endereco_profissional_cep); ?><?php endif; ?>
          </div>
          <div class="form-group col-md-4">
            <label>Bairro</label>
            <?php if(isset($user)): ?><?php echo e($user->endereco_profissional_bairro); ?><?php endif; ?>
          </div>
          <div class="form-group col-md-4">
            <label>Cidade</label>
            <?php if(isset($user)): ?><?php echo e($user->endereco_profissional_cidade); ?><?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="box-footer">
    <button type="submit" class="btn btn-primary"><?php if(isset($user)): ?>Atualizar <?php else: ?> Salvar <?php endif; ?></button>
    <a href="<?php echo e(route('user.index')); ?>" class="btn">Voltar</a>
  </div>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\site-ak\resources\views/admin/user/show.blade.php ENDPATH**/ ?>