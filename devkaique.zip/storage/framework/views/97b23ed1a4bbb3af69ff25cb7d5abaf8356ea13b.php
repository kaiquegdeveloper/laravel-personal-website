<?php $__env->startSection('title', 'Configurations'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
  <div class="col-md-12">
  <h1>Editar Configurações do Sistema</h1>

  <ol class="breadcrumb">
  <li><a href="<?php echo e(route('admin.index')); ?>">Dashboard</a></li>
  </ol></div></div>

<?php echo $__env->make('includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<form enctype="multipart/form-data" role="form" method="post" action=" <?php if(isset($configuration->id)): ?> <?php echo e(route('configuration.update',$configuration->id)); ?> <?php else: ?> <?php echo e(route('configuration.store')); ?> <?php endif; ?> ">
<?php echo csrf_field(); ?>

<div class="row">
  <div class="col-md-6">
    <div class="box box-danger">
      <div class="box-header with-border">
        <h3 class="box-title">Dados de Acesso</h3>
      </div>
        <?php if(isset($configuration->id)): ?>
          <input type="hidden" value="<?php echo e($configuration->id); ?>" name="id" />
          <?php echo e(method_field('PATCH')); ?>

        <?php endif; ?>
        <div class="box-body">
          <div class="form-group">
            <label>Nome do site</label>
            <input class="form-control" type="text" name="sitename" value="<?php if(isset($configuration)): ?><?php echo e($configuration->sitename); ?><?php endif; ?>" />
          </div>
          <div class="form-group">
            <label>Descrição para o site</label>
            <input class="form-control" type="text" name="description" value="<?php if(isset($configuration)): ?><?php echo e($configuration->description); ?><?php endif; ?>" />
          </div>
          <div class="form-group">
            <label>Logotipo</label>

            <?php if(isset($configuration->logotipo)): ?>
              <img src="<?php echo e(asset('/images/uploads/')); ?>/<?php echo e($configuration->logotipo); ?>" width="200px" />
            <?php endif; ?>
              <a id="show-input" href="#" onclick="show()" class="btn">Adicionar nova</a>
              <div id="input-image" style="display:none">
                <input name="logotipo" type="file" />
              </div>
              <script>
                  function show(){
                      document.getElementById('input-image').style.display = 'block';
                  }
              </script>

          </div>
        </div>
    </div>
  </div>
  <!-- coluna direita -->

    <div class="col-md-6">
      <div class="box box-info">
        <div class="box-body">
          <div class="form-group">
            <label>CNPJ</label>
            <input class="form-control cnpj" id="cnpj" type="text" name="cnpj" placeholder="00.000.000/0000-00" value="<?php if(isset($configuration)): ?><?php echo e($configuration->cnpj); ?><?php endif; ?>" />
          </div>
          <div class="form-group">
            <label>Nome fantasia</label>
            <input class="form-control" type="text" name="nome_fantasia" value="<?php if(isset($configuration)): ?><?php echo e($configuration->nome_fantasia); ?><?php endif; ?>" />
          </div>
          <div class="form-group">
            <label>Data de abertura</label>
            <input class="form-control" type="date" name="data_abertura" value="<?php if(isset($configuration)): ?><?php echo e($configuration->data_abertura); ?><?php endif; ?>" />
          </div>
          <div class="form-group">
            <label>Natureza Juridica</label>
            <input class="form-control" type="text" name="natureza_juridica" value="<?php if(isset($configuration)): ?><?php echo e($configuration->natureza_juridica); ?><?php endif; ?>" />
          </div>
          <div class="form-group">
            <label>Nome Representante</label>
            <input class="form-control" type="text" name="representante" value="<?php if(isset($configuration)): ?><?php echo e($configuration->representante); ?><?php endif; ?>" />
          </div>
          <div class="form-group">
            <label>Documento</label>
            <input class="form-control" type="text" name="documento" value="<?php if(isset($configuration)): ?><?php echo e($configuration->documento); ?><?php endif; ?>" />
          </div>
          <div class="form-group">
            <label>Estado Civil</label>
            <input class="form-control" type="text" name="estado_civil" value="<?php if(isset($configuration)): ?><?php echo e($configuration->estado_civil); ?><?php endif; ?>" />
          </div>
          <div class="form-group">
            <label>nacionalidade</label>
            <input class="form-control" type="text" name="nacionalidade" value="<?php if(isset($configuration)): ?><?php echo e($configuration->nacionalidade); ?><?php endif; ?>" />
          </div>
        </div>
      </div>
    </div>
</div>

<div class="row">
  <div class="col-md-12">
    <div class="box box-info">
      <div class="box-header with-border">
        <h3 class="box-title">Contatos</h3>
        <div class="box-tools pull-right">
          <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
        </div>
      </div>
      <div class="box-body">
        <div class="form-group col-md-2">
          <label>CEP</label>
          <input id="cep" class="form-control" type="text" name="cep" value="<?php if(isset($configuration)): ?><?php echo e($configuration->cep); ?><?php endif; ?>" />
        </div>
        <div class="form-group col-md-1">
          <label>Número</label>
          <input class="form-control" type="text" name="numero" value="<?php if(isset($configuration)): ?><?php echo e($configuration->numero); ?><?php endif; ?>" />
        </div>
        <div class="form-group col-md-4">
          <label>Endereço Residencial</label>
          <input class="form-control" type="text" name="logradouro" value="<?php if(isset($configuration)): ?><?php echo e($configuration->logradouro); ?><?php endif; ?>" />
        </div>
        <div class="form-group col-md-2">
          <label>Complemento</label>
          <input class="form-control" type="text" name="complemento" value="<?php if(isset($configuration)): ?><?php echo e($configuration->complemento); ?><?php endif; ?>" />
        </div>
        <div class="form-group col-md-2">
          <label>Bairro</label>
          <input class="form-control" type="text" name="bairro" value="<?php if(isset($configuration)): ?><?php echo e($configuration->bairro); ?><?php endif; ?>" />
        </div>
        <div class="form-group col-md-4">
          <label>Municipio</label>
          <input class="form-control" type="text" name="municipio" value="<?php if(isset($configuration)): ?><?php echo e($configuration->municipio); ?><?php endif; ?>" />
        </div>
        <div class="form-group col-md-1">
          <label>UF</label>
          <input class="form-control" type="text" name="uf" value="<?php if(isset($configuration)): ?><?php echo e($configuration->uf); ?><?php endif; ?>" />
        </div>
        <div class="form-group col-md-3">
          <label>Telefones (Separar por vírgula)</label>
          <input class="form-control" type="text" name="contato_telefone" value="<?php if(isset($configuration)): ?><?php echo e($configuration->contato_telefone); ?><?php endif; ?>" />
        </div>
        <div class="form-group col-md-3">
          <label>Email</label>
          <input class="form-control" type="text" name="contato_email" value="<?php if(isset($configuration)): ?><?php echo e($configuration->contato_email); ?><?php endif; ?>" />
        </div>
      </div>
    </div>
  </div>
</div>
<div class="row">
  <div class="col-md-6">
    <div class="box box-info">
      <div class="box-header with-border">
        <h3 class="box-title">Redes Sociais</h3>
        <div class="box-tools pull-right">
          <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
        </div>
      </div>
      <div class="box-body">
        <div class="form-group">
          <label>Facebook</label>
          <input class="form-control" type="text" name="link_facebook" value="<?php if(isset($configuration->link_facebook)): ?><?php echo e($configuration->link_facebook); ?><?php endif; ?>" />
        </div>
        <div class="form-group">
          <label>Twitter</label>
          <input class="form-control" type="text" name="link_twitter" value="<?php if(isset($configuration->link_twitter)): ?><?php echo e($configuration->link_twitter); ?><?php endif; ?>" />
        </div>
        <div class="form-group">
          <label>Instagram</label>
          <input class="form-control" type="text" name="link_instagram" value="<?php if(isset($configuration->link_instagram)): ?><?php echo e($configuration->link_instagram); ?><?php endif; ?>" />
        </div>
        <div class="form-group">
          <label>Linkedin</label>
          <input class="form-control" type="text" name="link_linkedin" value="<?php if(isset($configuration->link_linkedin)): ?><?php echo e($configuration->link_linkedin); ?><?php endif; ?>" />
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-6">
    <div class="box box-info">
      <div class="box-header with-border">
        <h3 class="box-title">Configuração API</h3>
        <div class="box-tools pull-right">
          <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
        </div>
      </div>
      <div class="box-body">
        <div class="form-group">
          <label>Google Analytics</label>
          <input class="form-control" type="text" name="google_analytics" value="<?php if(isset($configuration->google_analytics)): ?><?php echo e($configuration->google_analytics); ?><?php endif; ?>" />
        </div>
      </div>
    </div>
  </div>
</div>

  <div class="box-footer">
    <button type="submit" class="btn btn-primary"><?php if(isset($configuration)): ?>Atualizar <?php else: ?> Salvar <?php endif; ?></button>
    
  </div>

</form>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="<?php echo e(asset('js/jquery.mask.min.js')); ?>"></script>
<script>
  $(document).ready(function(){
  $('#cep').mask('00000-000');
  $('#cnpj').mask('00.000.000/0000-00', {reverse: true});
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\site-ak\resources\views/admin/configuration/edit.blade.php ENDPATH**/ ?>