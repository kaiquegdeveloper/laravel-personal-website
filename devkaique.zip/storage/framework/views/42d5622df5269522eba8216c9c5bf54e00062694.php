<?php $__env->startSection('title'); ?>
Início | AK Desenvolvimento
<?php $__env->stopSection(); ?>
<?php $__env->startSection('seo'); ?>
<!-- Primary Meta Tags -->
<title>AK Desenvolvimento | Time de Desenvolvimento Web</title>
<meta name="title" content="AK Desenvolvimento | Time de Desenvolvimento Web">
<meta name="description" content="Nós somos um time especializado em atender a necessidade do seu negócio, criando as soluções ideais pelo melhor custo benefício! conheça agora mesmo!">
<meta name="keywords" content="desenvolvimento,web,agencia,ti,sites,blogs,lojas,virtuais,marketplace,ecommerce,hospedagem,de,sites">
<meta name="robots" content="index, follow">
<meta name="author" content="AK Desenvolvimento">
<!-- Open Graph / Facebook -->
<meta property="og:type" content="website">
<meta property="og:url" content="http://akdesenvolvimento.com.br/">
<meta property="og:title" content="AK Desenvolvimento | Time de Desenvolvimento Web">
<meta property="og:description" content="Nós somos um time especializado em atender a necessidade do seu negócio, criando as soluções ideais pelo melhor custo benefício! conheça agora mesmo!">
<meta property="og:image" content="http://lp.akdesenvolvimento.com.br/hospedagem/img/logo/dark.png">

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="http://akdesenvolvimento.com.br/">
<meta property="twitter:title" content="AK Desenvolvimento | Time de Desenvolvimento Web">
<meta property="twitter:description" content="Nós somos um time especializado em atender a necessidade do seu negócio, criando as soluções ideais pelo melhor custo benefício! conheça agora mesmo!">
<meta property="twitter:image" content="http://lp.akdesenvolvimento.com.br/hospedagem/img/logo/dark.png">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="slice py-7">
    <div class="container">
        <div class="row row-grid align-items-center">
            <div class="col-12 col-md-5 col-lg-6 order-md-2 text-center">
                <!-- Image -->
                <figure class="w-100">
                    <img alt="Image placeholder" src="<?php echo e(asset('assets/img/svg/illustrations/illustration-3.svg')); ?>" class="img-fluid mw-md-120">
                </figure>
            </div>
            <div class="col-12 col-md-7 col-lg-6 order-md-1 pr-md-5">
                <!-- Heading -->
                <h1 class="display-4 text-center text-md-left mb-3">
                    Está na hora de repensar sua <strong class="text-primary">presença digital</strong>
                </h1>
                <!-- Text -->
                <p class="lead text-center text-md-left text-muted">
                    Nós utilizamos as melhores e mais atuais tecnologias para criar a melhor solução para sua marca.
                </p>
                <!-- Buttons -->
                <div class="text-center text-md-left mt-5">
                    <a href="#comotrabalhamos" class="btn btn-primary btn-icon">
                        <span class="btn-inner--text">Vamos lá</span>
                        
                    </a>
                    
                </div>
            </div>
        </div>
    </div>
</section>
<section class="slice slice-lg pt-lg-6 pb-0 pb-lg-6 bg-section-secondary" id="comotrabalhamos">
    <div class="container">
        <!-- Title -->
        <!-- Section title -->
        <div class="row mb-5 justify-content-center text-center">
            <div class="col-lg-6">
                
                <h2 class=" mt-4">Como nós trabalhamos?</h2>
                <div class="mt-2">
                    <p class="lead lh-180">Nosso time possui know-how para te atender!</p>
                </div>
            </div>
        </div>
        <!-- Card -->
        <div class="row mt-5">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body pb-5">
                        <div class="pt-4 pb-5">
                            <img src="<?php echo e(asset('assets/img/svg/illustrations/illustration-5.svg')); ?>" class="img-fluid img-center" style="height: 150px;" alt="Illustration" />
                        </div>
                        <h5 class="h4 lh-130 mb-3">Reunião com o Cliente</h5>
                        <p class="text-muted mb-0">
                            Nosso time entra em contato com você e elaboramos um briefing baseado na sua necessidade, discutimos as opçoes e retornamos com a ideia da solução!
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body pb-5">
                        <div class="pt-4 pb-5">
                            <img src="<?php echo e(asset('assets/img/svg/illustrations/illustration-6.svg')); ?>" class="img-fluid img-center" style="height: 150px;" alt="Illustration" />
                        </div>
                        <h5 class="h4 lh-130 mb-3">Projetamos a Solução</h5>
                        <p class="text-muted mb-0">Nossa equipe de designers e desenvolvedores dão início e criam a solução perfeita para o seu negócio.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body pb-5">
                        <div class="pt-4 pb-5">
                            <img src="<?php echo e(asset('assets/img/svg/illustrations/illustration-7.svg')); ?>" class="img-fluid img-center" style="height: 150px;" alt="Illustration" />
                        </div>
                        <h5 class="h4 lh-130 mb-3">Você atinge os resultados!</h5>
                        <p class="text-muted mb-0">Nossa equipe implementa a sua solução e segue monitorando para assegurar que você atinja os resultados que almeja</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="slice slice-lg bg-section-dark pt-5 pt-lg-8">
    <!-- SVG separator -->
    <div class="shape-container shape-line shape-position-top shape-orientation-inverse">
        <svg width="2560px" height="100px" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" preserveAspectRatio="none" x="0px" y="0px" viewBox="0 0 2560 100" style="enable-background:new 0 0 2560 100;" xml:space="preserve" class="">
            <polygon points="2560 0 2560 100 0 100"></polygon>
        </svg>
    </div>
    <!-- Container -->
    <div class="container position-relative zindex-100">
        <div class="col">
            <div class="row justify-content-center">
                <div class="col-md-10 text-center">
                    <div class="mt-4 mb-6">
                        <h2 class="h1 text-white">
                            Preparado para obter resultados?
                        </h2>
                        <h4 class="text-white mt-3">Criamos soluções baseadas na sua necessidade</h4>
                        <!-- Play button -->
                    <a href="<?php echo e(route('contato')); ?>" class="btn btn-primary btn-icon mt-4">Fale com um especialista!</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="slice slice-lg">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <span class="badge badge-primary badge-pill">Nossa área de atuação</span>
                <h5 class="lh-180 mt-4 mb-6">
                    Nós somos uma agência especializada em atender as necessidades do seu negócio e projetar a solução 
                    ideal dentro das áreas: Desenvolvimento Web, Mobile, SEO, Design Gráfico, Marketing digital e Hospedagem de sites.
                </h5>
            </div>
        </div>
        <!-- Features -->
        <div class="row mx-lg-n4">
            <!-- Features - Col 1 -->
            <div class="col-lg-4 col-md-6 px-lg-4">
                <div class="card shadow-none">
                    <div class="p-3 d-flex">
                        <div>
                            <div class="icon icon-shape rounded-circle bg-warning text-white mr-4">
                                <i data-feather="check"></i>
                            </div>
                        </div>
                        <div>
                            <span class="h6">Sites institucionais</span>
                            <p class="text-sm text-muted mb-0">
                                Para apresentar a sua empresa
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 px-lg-4">
                <div class="card shadow-none">
                    <div class="p-3 d-flex">
                        <div>
                            <div class="icon icon-shape rounded-circle bg-primary text-white mr-4">
                                <i data-feather="check"></i>
                            </div>
                        </div>
                        <div>
                            <span class="h6">Lojas virtuais WooCommerce</span>
                            <p class="text-sm text-muted mb-0">
                                Para expandir as vendas do seu comércio.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 px-lg-4">
                <div class="card shadow-none">
                    <div class="p-3 d-flex">
                        <div>
                            <div class="icon icon-shape rounded-circle bg-danger text-white mr-4">
                                <i data-feather="check"></i>
                            </div>
                        </div>
                        <div>
                            <span class="h6">Sistemas Personalizados</span>
                            <p class="text-sm text-muted mb-0">
                                Para solucionar o seu problema.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 px-lg-4">
                <div class="card shadow-none">
                    <div class="p-3 d-flex">
                        <div>
                            <div class="icon icon-shape rounded-circle bg-success text-white mr-4">
                                <i data-feather="check"></i>
                            </div>
                        </div>
                        <div>
                            <span class="h6">Google ADS</span>
                            <p class="text-sm text-muted mb-0">
                                Para alavancar seu negócio.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 px-lg-4">
                <div class="card shadow-none">
                    <div class="p-3 d-flex">
                        <div>
                            <div class="icon icon-shape rounded-circle bg-info text-white mr-4">
                                <i data-feather="check"></i>
                            </div>
                        </div>
                        <div>
                            <span class="h6">Blogs Wordpress</span>
                            <p class="text-sm text-muted mb-0">
                                Para você criar conteúdo para seus seguidores.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 px-lg-4">
                <div class="card shadow-none">
                    <div class="p-3 d-flex">
                        <div>
                            <div class="icon icon-shape rounded-circle bg-warning text-white mr-4">
                                <i data-feather="check"></i>
                            </div>
                        </div>
                        <div>
                            <span class="h6">Landing Pages</span>
                            <p class="text-sm text-muted mb-0">
                                Para você vender mais.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Features - Col 3 -->
            <div class="col-lg-4 col-md-6 px-lg-4">
                <div class="card shadow-none">
                    <div class="p-3 d-flex">
                        <div>
                            <div>
                                <div class="icon icon-shape rounded-circle bg-info text-white mr-4">
                                    <i data-feather="check"></i>
                                </div>
                            </div>
                        </div>
                        <div>
                            <span class="h6">Identidade Visual</span>
                            <p class="text-sm text-muted mb-0">
                                Para transparecer a sua ideia ao público.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 px-lg-4">
                <div class="card shadow-none">
                    <div class="p-3 d-flex">
                        <div>
                            <div>
                                <div class="icon icon-shape rounded-circle bg-danger text-white mr-4">
                                    <i data-feather="check"></i>
                                </div>
                            </div>
                        </div>
                        <div>
                            <span class="h6">Marketing Digital</span>
                            <p class="text-sm text-muted mb-0">
                                Para fazer o seu negócio crescer.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 px-lg-4">
                <div class="card shadow-none">
                    <div class="p-3 d-flex">
                        <div>
                            <div>
                                <div class="icon icon-shape rounded-circle bg-primary text-white mr-4">
                                    <i data-feather="check"></i>
                                </div>
                            </div>
                        </div>
                        <div>
                            <span class="h6">Hospedagem de Sites</span>
                            <p class="text-sm text-muted mb-0">
                                Para garantir segurança e suporte a você.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\site-ak\resources\views/index_production.blade.php ENDPATH**/ ?>