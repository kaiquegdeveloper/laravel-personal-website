<?php $__env->startSection('title', 'Page'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="col-md-12">
    <h1>Categorias de Post</h1>

    <ol class="breadcrumb">
      <li><a href="<?php echo e(route('admin.index')); ?>">Dashboard</a></li> &nbsp;
      <li><a href="">Categorias de Post</a></li>
    </ol>
  </div>
</div>
<div class="box box-primary">

  <div class="box-header with-border">
    <h3 class="box-title"></h3>
  </div>

  <?php echo $__env->make('includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <form enctype="multipart/form-data" role="form" method="post"
    action=" <?php if(isset($category->id)): ?> <?php echo e(route('postCategory.update',$category->id)); ?> <?php else: ?> <?php echo e(route('postCategory.store')); ?> <?php endif; ?> ">
    <?php echo csrf_field(); ?>

    <?php if(isset($category->id)): ?>
    <input type="hidden" value="<?php echo e($category->id); ?>" name="id" />
    <?php echo e(method_field('PATCH')); ?>

    <?php endif; ?>
    <div class="box-body">
      <div class="form-group">
        <label>Nome</label>
        <input class="form-control" placeholder="Inserir Nome" type="text" name="title"
          value="<?php if(isset($category)): ?><?php echo e($category->title); ?><?php endif; ?>">
      </div>
      <div class="form-group">
        <label>Descrição</label>
        <input class="form-control" name="description" type="text"
          value="<?php if(isset($category)): ?><?php echo e($category->description); ?><?php endif; ?>">
      </div>
      <div class="form-group">
        <label>Imagem destaque da página</label>
        <a id="show-input" class="btn">Adicionar nova</a>
        <div class="form-group" id="input-image" style="display:none">
          <input name="main_image" type="file" />
        </div>

        <?php if(isset($category->main_image)): ?>
        <img class="form-group" src="<?php echo e(URL::to('/images/uploads/blog')); ?>/<?php echo e($category->main_image); ?>" width="400px" />
        <?php endif; ?>
      </div>
      <div class="form-group">
        <label>Conteudo</label>
        <textarea class="form-control" name="content"
          id="editor"><?php if(isset($category)): ?><?php echo e($category->content); ?><?php endif; ?></textarea>
      </div>
      <div class="form-group">
        <label>Url</label>
        <input class="form-control" name="url" type="text" value="<?php if(isset($category)): ?><?php echo e($category->url); ?><?php endif; ?>">
      </div>
      <div class="form-group">
        <label>Meta Title</label>
        <input class="form-control" name="meta_title" type="text"
          value="<?php if(isset($category)): ?><?php echo e($category->meta_title); ?><?php endif; ?>">
      </div>
      <div class="form-group">
        <label>Meta Keywords</label>
        <input class="form-control" name="meta_keywords" type="text"
          value="<?php if(isset($category)): ?><?php echo e($category->meta_keywords); ?><?php endif; ?>">
      </div>
      <div class="form-group">
        <label>Meta Description</label>
        <input class="form-control" name="meta_description" type="text"
          value="<?php if(isset($category)): ?><?php echo e($category->meta_description); ?><?php endif; ?>">
      </div>
    </div>

    <div class="box-footer">
      <button type="submit" class="btn btn-primary"><?php if(isset($category)): ?>Atualizar <?php else: ?> Salvar <?php endif; ?></button>
      <a href="<?php echo e(route('postCategory.index')); ?>" class="btn">Voltar</a>
    </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('js'); ?>

    <script type="text/javascript">
      jQuery.noConflict();
    jQuery(document).ready(function(){
      jQuery("#show-input").on("click", function(e){
          e.preventDefault();
          jQuery("#input-image").toggle();
      });

    });
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\site-ak\resources\views/admin/postCategory/edit.blade.php ENDPATH**/ ?>