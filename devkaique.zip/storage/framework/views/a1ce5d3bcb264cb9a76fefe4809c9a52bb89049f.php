<?php $__env->startSection('title', 'Configuration'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="col-md-12">
    <h1>Configurações do Sistema</h1>

    <ol class="breadcrumb">
      <li><a href="<?php echo e(route('admin.index')); ?>">Dashboard</a></li> &nbsp;
      <li><a href="">Configurações</a></li>
    </ol>
  </div>
</div>

<?php echo $__env->make('includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
  <div class="col-md-6">
    <div class="box box-danger">
      <div class="box-header with-border">
        <h3 class="box-title">Dados de Acesso</h3>
      </div>
      <?php if(isset($configuration->id)): ?>
      <input type="hidden" value="<?php echo e($configuration->id); ?>" name="id" />
      <?php echo e(method_field('PATCH')); ?>

      <?php endif; ?>
      <div class="box-body">
        <div class="form-group"><?php echo e($configuration->sitename); ?></div>
        <div class="form-group"><?php echo e($configuration->description); ?></div>
        <div class="form-group">
          <?php if(isset($configuration->logotipo)): ?>
          <img src="<?php echo e(asset('/images/uploads/')); ?>/<?php echo e($configuration->logotipo); ?>" width="200px"
            style="background-color:black" />
          <?php endif; ?>
        </div>
      </div>
    </div>
    <div class="box box-success">
      <div class="box-header with-border">
        <h3 class="box-title">Contatos</h3>
      </div>
      <div class="box-body">
        <strong><i class="fa fa-book margin-r-5"></i> Endereço</strong>
        <p class="text-muted"><?php echo e($configuration->logradouro); ?>, <?php echo e($configuration->numero); ?>

          <?php echo e($configuration->bairro); ?> <?php echo e($configuration->municipio); ?> <?php echo e($configuration->uf); ?></p>
        <hr>
        <strong><i class="fa fa-book margin-r-5"></i> CEP</strong>
        <p class="text-muted"><?php echo e($configuration->cep); ?></p>
        <hr>
        <strong><i class="fa fa-book margin-r-5"></i> Data de abertura</strong>
        <p class="text-muted"><?php echo e($configuration->complemento); ?></p>
        <hr>
        <strong><i class="fa fa-book margin-r-5"></i> Telefones</strong>
        <p class="text-muted"><?php echo e($configuration->contato_telefone); ?></p>
        <hr>
        <strong><i class="fa fa-book margin-r-5"></i> Email</strong>
        <p class="text-muted"><?php echo e($configuration->contato_email); ?></p>
        <hr>
      </div>
    </div>
  </div>
  <!-- coluna direita -->
  <div class="col-md-6">
    <div class="box box-info">
      <div class="box-body">
        <div class="form-group col-md-12">
          <div class="btn-group"><a href="<?php echo e(route('configuration.edit',$configuration->id)); ?>"
              class="btn btn-warning pull-left">Editar</a></div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-6">
    <div class="box box-success">
      <div class="box-header with-border">
        <h3 class="box-title">Documentos</h3>
      </div>
      <div class="box-body">
        <strong><i class="fa fa-book margin-r-5"></i> Data de abertura</strong>
        <p class="text-muted"><?php echo e($configuration->data_abertura); ?></p>
        <hr>
        <strong><i class="fa fa-book margin-r-5"></i> Nome Fantasia</strong>
        <p class="text-muted"><?php echo e($configuration->nome_fantasia); ?></p>
        <hr>
        <strong><i class="fa fa-book margin-r-5"></i> CNPJ</strong>
        <p class="text-muted"><?php echo e($configuration->cnpj); ?></p>
        <hr>
        <strong><i class="fa fa-book margin-r-5"></i> Natureza Juridica</strong>
        <p class="text-muted"><?php echo e($configuration->natureza_juridica); ?></p>
        <hr>
        <strong><i class="fa fa-book margin-r-5"></i> Representada por:</strong>
        <p class="text-muted"><?php echo e($configuration->representante); ?></p>
        <hr>
        <strong><i class="fa fa-book margin-r-5"></i> Documento</strong>
        <p class="text-muted"><?php echo e($configuration->documento); ?></p>
        <hr>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\devkaique\resources\views/admin/configuration/show.blade.php ENDPATH**/ ?>