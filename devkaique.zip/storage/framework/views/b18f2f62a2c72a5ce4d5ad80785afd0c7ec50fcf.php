<?php $__env->startComponent('mail::message'); ?>

   <b> Novo contato a partir do site da AK Desenvolvimento</b>
   <hr>
   <b>Nome:</b> <?php echo e($data["nome"]); ?> <br>
   <b>Email:</b> <?php echo e($data["email"]); ?> <br>
   <b>Assunto:</b> <?php echo e($data["assunto"]); ?> <br>
   <b>Mensagem:</b> <?php echo e($data["mensagem"]); ?> <br>

<?php echo $__env->renderComponent(); ?><?php /**PATH C:\laragon\www\devkaique\resources\views/mail/contact.blade.php ENDPATH**/ ?>